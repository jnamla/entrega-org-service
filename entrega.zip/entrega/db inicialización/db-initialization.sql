-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema organisation
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `organisation` ;

-- -----------------------------------------------------
-- Schema organisation
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `organisation` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `organisation` ;

-- -----------------------------------------------------
-- Table `organisation`.`country`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `organisation`.`country` ;

CREATE TABLE IF NOT EXISTS `organisation`.`country` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `code` CHAR(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `name_UNIQUE` (`name` ASC) VISIBLE,
  UNIQUE INDEX `code_UNIQUE` (`code` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `organisation`.`state`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `organisation`.`state` ;

CREATE TABLE IF NOT EXISTS `organisation`.`state` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `country_id` INT(11) NOT NULL,
  `name` VARCHAR(45) NOT NULL,
  `code` CHAR(4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `code_UNIQUE` (`code` ASC) VISIBLE,
  UNIQUE INDEX `name_UNIQUE` (`name` ASC) VISIBLE,
  INDEX `fk_State_Country1_idx` (`country_id` ASC) VISIBLE,
  CONSTRAINT `fk_State_Country1`
    FOREIGN KEY (`country_id`)
    REFERENCES `organisation`.`country` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `organisation`.`city`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `organisation`.`city` ;

CREATE TABLE IF NOT EXISTS `organisation`.`city` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `state_id` INT(11) NOT NULL,
  `name` VARCHAR(45) NOT NULL,
  `Code` CHAR(4) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_City_State1_idx` (`state_id` ASC) VISIBLE,
  CONSTRAINT `fk_City_State1`
    FOREIGN KEY (`state_id`)
    REFERENCES `organisation`.`state` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `organisation`.`generic_area`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `organisation`.`generic_area` ;

CREATE TABLE IF NOT EXISTS `organisation`.`generic_area` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `description` VARCHAR(90) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 7
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `organisation`.`area`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `organisation`.`area` ;

CREATE TABLE IF NOT EXISTS `organisation`.`area` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `generic_area_id` INT(11) NOT NULL,
  `city_id` INT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_area_generic_area1_idx` (`generic_area_id` ASC) VISIBLE,
  INDEX `fk_area_city1_idx` (`city_id` ASC) VISIBLE,
  CONSTRAINT `fk_area_city1`
    FOREIGN KEY (`city_id`)
    REFERENCES `organisation`.`city` (`id`),
  CONSTRAINT `fk_area_generic_area1`
    FOREIGN KEY (`generic_area_id`)
    REFERENCES `organisation`.`generic_area` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 19
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `organisation`.`asset_status`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `organisation`.`asset_status` ;

CREATE TABLE IF NOT EXISTS `organisation`.`asset_status` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `description` VARCHAR(32) NOT NULL,
  `code` CHAR(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `code_UNIQUE` (`code` ASC) VISIBLE,
  UNIQUE INDEX `name_UNIQUE` (`name` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 6
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `organisation`.`asset_type`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `organisation`.`asset_type` ;

CREATE TABLE IF NOT EXISTS `organisation`.`asset_type` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `code` CHAR(4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `code_UNIQUE` (`code` ASC) VISIBLE,
  UNIQUE INDEX `name_UNIQUE` (`name` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 4
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `organisation`.`personnel`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `organisation`.`personnel` ;

CREATE TABLE IF NOT EXISTS `organisation`.`personnel` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `middle_name` VARCHAR(45) NULL DEFAULT NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `additional_last_names` VARCHAR(45) NULL DEFAULT NULL,
  `password` VARCHAR(32) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `create_time` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 19
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `organisation`.`fixed_asset`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `organisation`.`fixed_asset` ;

CREATE TABLE IF NOT EXISTS `organisation`.`fixed_asset` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `description` VARCHAR(45) NOT NULL,
  `serial_number` VARCHAR(45) NULL DEFAULT NULL,
  `internal_stock_number` INT(11) NOT NULL,
  `weight` FLOAT NULL DEFAULT NULL,
  `height` FLOAT NULL DEFAULT NULL,
  `width` FLOAT NULL DEFAULT NULL,
  `asset_length` FLOAT NULL DEFAULT NULL,
  `purchase_value` FLOAT NOT NULL,
  `purchase_date` DATETIME NOT NULL,
  `out_of_stock_date` DATETIME NULL DEFAULT NULL,
  `color` VARCHAR(45) NOT NULL,
  `personnel_id` INT(11) NULL DEFAULT NULL,
  `area_id` INT(11) NULL DEFAULT NULL,
  `status_id` INT(11) NOT NULL,
  `asset_type_id` INT(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `name_UNIQUE` (`name` ASC) VISIBLE,
  UNIQUE INDEX `internal_stock_number_UNIQUE` (`internal_stock_number` ASC) VISIBLE,
  UNIQUE INDEX `serial_number_UNIQUE` (`serial_number` ASC) VISIBLE,
  INDEX `fk_FixedAssets_Personnel1_idx` (`personnel_id` ASC) VISIBLE,
  INDEX `fk_FixedAssets_Status1_idx` (`status_id` ASC) VISIBLE,
  INDEX `fk_FixedAsset_AssetType1_idx` (`asset_type_id` ASC) VISIBLE,
  INDEX `fk_fixed_asset_area1_idx` (`area_id` ASC) VISIBLE,
  CONSTRAINT `fk_FixedAsset_AssetType1`
    FOREIGN KEY (`asset_type_id`)
    REFERENCES `organisation`.`asset_type` (`id`),
  CONSTRAINT `fk_FixedAssets_Personnel1`
    FOREIGN KEY (`personnel_id`)
    REFERENCES `organisation`.`personnel` (`id`),
  CONSTRAINT `fk_FixedAssets_Status1`
    FOREIGN KEY (`status_id`)
    REFERENCES `organisation`.`asset_status` (`id`),
  CONSTRAINT `fk_fixed_asset_area1`
    FOREIGN KEY (`area_id`)
    REFERENCES `organisation`.`area` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 12
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
