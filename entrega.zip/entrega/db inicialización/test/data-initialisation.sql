INSERT INTO `organisation_test`.`country` (name, code) VALUES ("Colombia","COL");

INSERT INTO `organisation_test`.`state` (name, code, country_id) VALUES ("Cundinamarca","CUND", (SELECT id FROM `organisation_test`.`country` WHERE code = "COL" ));
INSERT INTO `organisation_test`.`state` (name, code, country_id) VALUES ("Antioquia","ANTQ", (SELECT id FROM `organisation_test`.`country` WHERE code = "COL" ));

INSERT INTO `organisation_test`.`city` (name, code, state_id) VALUES ("Medellín","MDE", (SELECT id FROM `organisation_test`.`state` WHERE code = "ANTQ" ));
INSERT INTO `organisation_test`.`city` (name, code, state_id) VALUES ("Santa fé de Bogotá","BOG", (SELECT id FROM `organisation_test`.`state` WHERE code = "CUND" ));

INSERT INTO `organisation_test`.`generic_area` (name, description) VALUES ("Administración","Encargados de el area contable y de recursos.");
INSERT INTO `organisation_test`.`generic_area` (name, description) VALUES ("Dirección","Encargados de definir los lineamientos de desarrollo.");
INSERT INTO `organisation_test`.`generic_area` (name, description) VALUES ("Ventas","Area engargada de publicidad y mercadeo.");
INSERT INTO `organisation_test`.`generic_area` (name, description) VALUES ("Recursos Humanos","Area engargada de personal.");
INSERT INTO `organisation_test`.`generic_area` (name, description) VALUES ("IT","Area engargada de tecnologías de información.");
INSERT INTO `organisation_test`.`generic_area` (name, description) VALUES ("Operación","Encargados del mantenimiento las instalaciones.");
INSERT INTO `organisation`.`generic_area` (name, description) VALUES ("Servicio al cliente","Encargados de proveer informacion y solucionar inquietudes.");


INSERT INTO `organisation_test`.`asset_status` (name, code, description) VALUES ("Activo", "ACT", "Está en uso");
INSERT INTO `organisation_test`.`asset_status` (name, code, description) VALUES ("Dado de baja", "INAC", "Fuera de inventario");
INSERT INTO `organisation_test`.`asset_status` (name, code, description) VALUES ("En reparación", "REP", "En taller");
INSERT INTO `organisation_test`.`asset_status` (name, code, description) VALUES ("Disponible", "DIS", "En espera para ser asignado");
INSERT INTO `organisation_test`.`asset_status` (name, code, description) VALUES ("Asignado", "ASIG", "Activo asignado");


INSERT INTO `organisation_test`.`asset_type` (name, code) VALUES ("Bienes inmuebles","INM");
INSERT INTO `organisation_test`.`asset_type` (name, code) VALUES ("Maquinaria","MACH");
INSERT INTO `organisation_test`.`asset_type` (name, code) VALUES ("Material de oficina","OFF");


INSERT INTO `organisation_test`.`area` (generic_area_id, city_id) VALUES ((SELECT id FROM `organisation_test`.`generic_area` WHERE name = "Administración"), (SELECT id FROM `organisation_test`.`city` WHERE code = "BOG"));
INSERT INTO `organisation_test`.`area` (generic_area_id, city_id) VALUES ((SELECT id FROM `organisation_test`.`generic_area` WHERE name = "Dirección"), (SELECT id FROM `organisation_test`.`city` WHERE code = "BOG"));
INSERT INTO `organisation_test`.`area` (generic_area_id, city_id) VALUES ((SELECT id FROM `organisation_test`.`generic_area` WHERE name = "Ventas"), (SELECT id FROM `organisation_test`.`city` WHERE code = "BOG"));
INSERT INTO `organisation_test`.`area` (generic_area_id, city_id) VALUES ((SELECT id FROM `organisation_test`.`generic_area` WHERE name = "Recursos Humanos"), (SELECT id FROM `organisation_test`.`city` WHERE code = "BOG"));
INSERT INTO `organisation_test`.`area` (generic_area_id, city_id) VALUES ((SELECT id FROM `organisation_test`.`generic_area` WHERE name = "IT"), (SELECT id FROM `organisation_test`.`city` WHERE code = "BOG"));
INSERT INTO `organisation_test`.`area` (generic_area_id, city_id) VALUES ((SELECT id FROM `organisation_test`.`generic_area` WHERE name = "Operación"), (SELECT id FROM `organisation_test`.`city` WHERE code = "BOG"));


INSERT INTO `organisation_test`.`area` (generic_area_id, city_id) VALUES ((SELECT id FROM `organisation_test`.`generic_area` WHERE name = "Administración"), (SELECT id FROM `organisation_test`.`city` WHERE code = "MDE"));
INSERT INTO `organisation_test`.`area` (generic_area_id, city_id) VALUES ((SELECT id FROM `organisation_test`.`generic_area` WHERE name = "Dirección"), (SELECT id FROM `organisation_test`.`city` WHERE code = "MDE"));
INSERT INTO `organisation_test`.`area` (generic_area_id, city_id) VALUES ((SELECT id FROM `organisation_test`.`generic_area` WHERE name = "Ventas"), (SELECT id FROM `organisation_test`.`city` WHERE code = "MDE"));
INSERT INTO `organisation_test`.`area` (generic_area_id, city_id) VALUES ((SELECT id FROM `organisation_test`.`generic_area` WHERE name = "Recursos Humanos"), (SELECT id FROM `organisation_test`.`city` WHERE code = "MDE"));
INSERT INTO `organisation_test`.`area` (generic_area_id, city_id) VALUES ((SELECT id FROM `organisation_test`.`generic_area` WHERE name = "IT"), (SELECT id FROM `organisation_test`.`city` WHERE code = "MDE"));
INSERT INTO `organisation_test`.`area` (generic_area_id, city_id) VALUES ((SELECT id FROM `organisation_test`.`generic_area` WHERE name = "Operación"), (SELECT id FROM `organisation_test`.`city` WHERE code = "MDE"));


INSERT INTO `organisation_test`.`personnel` (first_name, middle_name, last_name, additional_last_names, password, email) VALUES ("Johanna", "Marcela", "Palma", "Pabón", "9foemrfd9-0", "Johanna@gmail.com");
INSERT INTO `organisation_test`.`personnel` (first_name, middle_name, last_name, additional_last_names, password, email) VALUES ("John", "Marcelo", "Rocha", null, "9foemrfd9-0", "John@gmail.com");
INSERT INTO `organisation_test`.`personnel` (first_name, middle_name, last_name, additional_last_names, password, email) VALUES ("Pedro", null, "Ruiz", null, "9foemrfd9-0", "pruiz@gmail.com");
INSERT INTO `organisation_test`.`personnel` (first_name, middle_name, last_name, additional_last_names, password, email) VALUES ("Luis", "Mario", "Reyes", null, "9foemrfd9-0", "luismario@gmail.com");
INSERT INTO `organisation_test`.`personnel` (first_name, middle_name, last_name, additional_last_names, password, email) VALUES ("Mario", "Andres", "Romero", null, "9foemrfd9-0", "Mario@gmail.com");
INSERT INTO `organisation_test`.`personnel` (first_name, middle_name, last_name, additional_last_names, password, email) VALUES ("Oscar", "Alberto", "Urrego", "Torres", "9foemrfd9-0", "Oscar@gmail.com");
INSERT INTO `organisation_test`.`personnel` (first_name, middle_name, last_name, additional_last_names, password, email) VALUES ("Amparo", "Eugenia", "Diaz", null, "9foemrfd9-0", "Amparo@gmail.com");
INSERT INTO `organisation_test`.`personnel` (first_name, middle_name, last_name, additional_last_names, password, email) VALUES ("Angie", null, "Romero", "Jaramillo", "9foemrfd9-0", "Angie@gmail.com");
INSERT INTO `organisation_test`.`personnel` (first_name, middle_name, last_name, additional_last_names, password, email) VALUES ("Diana", "Marcela", "Duarte", "Torres", "9foemrfd9-0", "Diana@gmail.com");
INSERT INTO `organisation_test`.`personnel` (first_name, middle_name, last_name, additional_last_names, password, email) VALUES ("Juan", "Sebastian", "Toledo", null, "9foemrfd9-0", "Juan@gmail.com");
INSERT INTO `organisation_test`.`personnel` (first_name, middle_name, last_name, additional_last_names, password, email) VALUES ("Eduardo", "Augusto", "Tarud", "Turriago", "9foemrfd9-0", "Eduardo@gmail.com");
INSERT INTO `organisation_test`.`personnel` (first_name, middle_name, last_name, additional_last_names, password, email) VALUES ("Miguel", null, "Bautista", "Jaramillo", "9foemrfd9-0", "Miguel@gmail.com");
INSERT INTO `organisation_test`.`personnel` (first_name, middle_name, last_name, additional_last_names, password, email) VALUES ("Alfonso", "Ricardo", "Vidarte", null, "9foemrfd9-0", "Alfonso@gmail.com");
INSERT INTO `organisation_test`.`personnel` (first_name, middle_name, last_name, additional_last_names, password, email) VALUES ("Simon", "David", "Vidarte", "Lopera", "9foemrfd9-0", "Simon@gmail.com");
INSERT INTO `organisation_test`.`personnel` (first_name, middle_name, last_name, additional_last_names, password, email) VALUES ("Roberto", null, "Marcos", "Cuervo", "9foemrfd9-0", "Roberto@gmail.com");
INSERT INTO `organisation_test`.`personnel` (first_name, middle_name, last_name, additional_last_names, password, email) VALUES ("Mauricio", "Andres", "Marcos", "Vieda", "9foemrfd9-0", "Mauricio@gmail.com");
INSERT INTO `organisation_test`.`personnel` (first_name, middle_name, last_name, additional_last_names, password, email) VALUES ("Liliana", null, "Avila", null, "9foemrfd9-0", "Liliana@gmail.com");